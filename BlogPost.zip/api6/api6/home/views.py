from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from .models import post

def signup(req):
    if req.method=='POST':
        new_user=User.objects.create_user(
            username=req.POST.get('username'),
            email=req.POST.get('email'),
            password=req.POST.get('password'),
            first_name=req.POST.get('fname'),
            last_name=req.POST.get('lname'))
        return redirect('home:login')
    else:
        return render(req,'home/signup.html')

def loginUser(req):
    if req.method=='POST':
        user=authenticate(username=req.POST.get('username'),
        password=req.POST.get('password'))
        if user:
            login(req,user)
            return redirect('home:post')
        else:
            return HttpResponse('Invalid credentials or Access Blocked!')
    else:
        return render(req,'home/login.html')

@login_required
def addpost(req):
    if req.method=='POST':
        new_post=post()
        new_post.title=req.POST.get('title')
        new_post.content=req.POST.get('content')
        new_post.posted_by=req.user
        new_post.save()
        return redirect('home:index')
    else:
        return render(req,'home/post.html',{'data':req.user})

@login_required
def logoutUser(req):
    logout(req)
    return redirect('home:login')

def index(req):
    post1=post.objects.get(id=1)
    return render(req,'home/index.html',{'post':post1})