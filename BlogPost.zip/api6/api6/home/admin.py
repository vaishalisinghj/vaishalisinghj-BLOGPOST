from django.contrib import admin
from .models import post
from django.contrib.auth.models import User

admin.site.register(post)

